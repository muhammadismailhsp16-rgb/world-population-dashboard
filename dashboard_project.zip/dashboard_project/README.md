# 🌍 World Population Dashboard (2020)

**Course:** Exploratory Data Analysis  
**Instructor:** Ali Hassan Sherazi  
**Dataset:** `Population_by_country.xlsx` (235 countries/territories, 2020)

---

## 📦 Installation

```bash
# 1. Clone / unzip the project
cd dashboard_project

# 2. (Optional) Create a virtual environment
python -m venv venv
source venv/bin/activate    # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

---

## 🚀 Running the Dashboard

```bash
streamlit run app.py
```

Open your browser to **http://localhost:8501**

---

## 📁 Project Structure

```
dashboard_project/
├── data/
│   └── Population_by_country.xlsx   ← Dataset (exact filename, do not rename)
├── notebooks/
│   └── analysis.ipynb               ← Exploratory Data Analysis
├── app.py                           ← Main Streamlit dashboard
├── charts.py                        ← All chart/visualization functions
├── filters.py                       ← Data loading, cleaning, filtering
├── requirements.txt                 ← Python dependencies
└── README.md                        ← This file
```

---

## 📊 Charts Included

| # | Chart Type   | Purpose |
|---|-------------|---------|
| 1 | Pie Chart    | Population share by country size category |
| 2 | Histogram    | Frequency distribution of population |
| 3 | Line Chart   | Yearly growth % across top 15 countries |
| 4 | Bar Chart    | Top 15 most populous countries |
| 5 | Scatter Plot | Fertility rate vs Median age |
| 6 | Box Plot     | Median age by population category |
| 7 | Heatmap      | Correlation matrix across all features |
| 8 | Area Chart   | Cumulative population — top 10 countries |
| 9 | Count Plot   | Number of countries per population tier |
| 10| Violin Plot  | Urban population % by migration direction |

---

## 🎛 Filters

All filters are in the left sidebar and update **all charts simultaneously**:

- 🔍 **Search/Text Filter** — Filter countries by name keyword
- 📊 **Population Range Slider** — Min/max population range
- 🗂 **Population Category** — Multi-select size tiers (<1M … >500M)
- ✈️ **Migration Direction** — Positive / Negative / Neutral
- 🏙 **Density Slider** — Filter by population density (P/Km²)
- 🔄 **Reset All Filters** — Returns to defaults

---

## 💡 Key Insights

1. **Top 2 countries dominate global population:** China and India together account for ~36% of the world's 7.8 billion people.
2. **Most countries are small:** Over 60% of countries have populations under 10 million — the world's population is highly concentrated in a few nations.
3. **Fertility vs Age inverse relationship:** Countries with high fertility rates consistently show lower median ages, confirming demographic transition theory.
4. **Migration and urbanization:** Countries with positive net migration tend to have higher urban population percentages, suggesting urban economic pull factors.
5. **Low annual growth globally:** Most large economies show yearly growth rates under 1%, indicating an ongoing global demographic slowdown.
6. **Density outliers:** Small island and city-state territories (e.g., Monaco, Singapore) show extreme density values as outliers in box plots.

---

## 🛠 Tech Stack

| Tool | Role |
|------|------|
| Python 3.x | Core language |
| Pandas | Data loading, cleaning, filtering |
| NumPy | Numerical operations |
| Matplotlib | Core chart rendering |
| Seaborn | Statistical styling & advanced charts |
| Streamlit | Interactive frontend dashboard |
| OpenPyXL | Reading `.xlsx` files |
